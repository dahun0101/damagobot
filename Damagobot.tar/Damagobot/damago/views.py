# -*- coding: utf-8 -*-
from django.http import JsonResponse
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from damago.models import parent, child, job, personality, ages, parentTalk, childTalk, event, eventChoice, talkRejection, ending
import json, datetime, random
# Create your views here.
callChildBtn = ['아이 불러오기!']
createChild = '새로 시작합니다!\n\n아이의 이름을 입력해주세요.'
buttons = [[], [], [], []] # [0] : None. [1] : mode1 대응 버튼, [2] : 대화 선택지 버튼, [3] : 이벤트 선택지 버튼
introduceBtnText = '자기소개 하기!'
maxPsId = 7 #성격 id 최대 수
mode1BtnSize = 4 #mode 1 버튼 갯수
mode2BtnSize = 2 #mode 2 버튼 갯수 (가능한 대화 선택지 갯수)
plusSatisfaction = 15 #밥주기/용돈주기시 올라가는 만족도
muchSatisfaction = 80 #밥주기/용돈주기의 상한
lessSatisfaction = 30 #밥주기/용돈주기의 하한
eatSelfAge = 13 #스스로 밥을먹는 나이
minusSatisfactionTime = 5#분당 1씩 만족도 감소
mealCountForMonthUp = 2.5#식사 한번에 달 수가 증가하는 수
chatCountForMonthUp = 1.0#대화 한번에 달 수가 증가하는 수
plusFrByGiven = 5 #적당한 밥주기/용돈주기시 올라가는 친밀도
minusFrByGiven = 10 #과도/부족한 밥주기/용돈주기시 내려가는 친밀도
minusFrByReject = 3 #대화 거절시 내려가는 친밀도
downSatisfactionByChat = 10 #대화하기시 떨어지는 만족도
maxDieTime = 24#시간 이후에도 응답이 없었을시 죽음
eventProbability = 15#이벤트가 발생할 확률
ageChange = False
minChatSuccessProb = 33#최소한의 말 들을 확률
maxChatSuccesProb = 90#최대한의 말 들을 확률
maxEndingPriority = 3#엔딩의 최대 우선순위
#debugBtnText = '디버그용'

createMinRandomFr = 35
createMaxRandomFr = 55
createMinRandomInt = 0
createMaxRandomInt = 15
createMinRandomMor = 0
createMaxRandomMor = 15
createMinRandomArt = 0
createMaxRandomArt = 90

def keyboard(request):
    return JsonResponse({
        'type' : 'buttons',
        'buttons' : callChildBtn
    })

@csrf_exempt
def message(request):
    global  ageChange

    ageChange = False
    json_str = ((request.body).decode('utf-8'))
    received_json_data = json.loads(json_str)
    content = received_json_data['content']
    user_key = received_json_data['user_key']
    p = None
    try:
        p = parent.objects.get(ID = user_key)
    except:
        p = None
    if p == None: #parent 존재하지않음
        if content == callChildBtn[0]:
            p = parent(ID = user_key, mode = 0)
            p.save()
            return JsonResponse({
                'message' : {
                    'text' : createChild
                },
                'keyboard' : {
                    'type' : 'text'
                }
            })
    else:# parent 존재
        if p.mode == 0:#아이 생성
            if content == callChildBtn[0]:
                p = parent(ID=user_key, mode=0)
                p.save()
                return JsonResponse({
                    'message': {
                        'text': createChild
                    },
                    'keyboard': {
                        'type': 'text'
                    }
                })
            pid = random.randrange(0, maxPsId + 1)
            c = child(
            	parent = p,
            	name = content,
            	age = 1,
            	friendliness = random.randrange(createMinRandomFr, createMaxRandomFr + 1),
            	satisfaction = 50,
            	intelligence = random.randrange(createMinRandomInt, createMaxRandomInt + 1),
            	morality = random.randrange(createMinRandomMor, createMaxRandomMor + 1),
            	artAbility = random.randrange(createMinRandomArt, createMaxRandomArt),
            	ages = ages.objects.get(age = 1),
            	job = job.objects.get(name = '아기'),
            	personality = personality.objects.get(id = pid),
            	last_datetime = timezone.now())
            c.save()
            p.mode = 1
            p.save()
            mode1BtnAppend(c)
            return JsonResponse({
                'message' : {
                    'text' : '아이가 태어났습니다! 축하합니다!'
                },
                'keyboard' : {
                    'type' : 'buttons',
                    'buttons' : buttons[p.mode]
                }
            })
        else:
            c = child.objects.get(parent_id=user_key)
            c_time = c.last_datetime
            now = timezone.now()
            time_dif = now - c_time
            minute_dif = int(time_dif.total_seconds() / 60)
            c.last_datetime = now
            c.save()
            cName = c.name
            mode1BtnAppend(c)
            if c.age < eatSelfAge:
                c.satisfaction -= int(minute_dif / minusSatisfactionTime)
                c.save()
            if minute_dif < 60 * maxDieTime:#굶어죽을 시간 이내에 응답하는 경우
                if c.satisfaction <= 0:#아무리 배고파도 죽지않고 포만감 1로변경
                    c.satisfaction = 1
                    c.save()
            else:#굶어죽을 시간동안 방치
                c.satisfaction = 0
                c.save()
                end = findEnding(c, p)
            if content == callChildBtn[0]:#아이 부르기 버튼 클릭
                mode1BtnAppend(c)
                mode2BtnAppend(c)
                if p.mode == 3:
                	mode3BtnAppend(p.event_ing, c)
                return JsonResponse({
                    'message' : {
                        'text' : cName + ' 안녕!'
                    },
                    'keyboard' : {
                        'type' : 'buttons',
                        'buttons' : buttons[p.mode]
                    }
                })
            if p.mode == 1:#mode1
                if content == buttons[1][0]:#대화하기
                    c.month += chatCountForMonthUp #개월 수 증가
                    c.satisfaction -= downSatisfactionByChat #포만감 감소
                    c.save()
                    checkStatus(c)
                    end = findEnding(c, p)
                    if end != None:
                    	return JsonResponse({
                    			'message' : {
                    				'text' : makeEndingMessage(end)
                    			},
                    			'keyboard' : {
                    				'type' : 'buttons',
                    				'buttons' : callChildBtn
                    			}
                    		})
                    try:#아이 성격에 맞는 거절확률 조사
                        rejProb = talkRejection.objects.get(personality = c.personality)
                    except:#없을 시 공통 성격의 거절확률
                        rejProb = talkRejection.objects.get(personality = personality.objects.get(id = -1))
                    dice = random.randrange(0, 100)#0~100 임의의 숫자 선택
                    prob = c.friendliness + rejProb.probability
                    if prob < minChatSuccessProb:
                    	prob = minChatSuccessProb#최소 말 들을 확률
                    elif prob > maxChatSuccesProb:
                    	prob = maxChatSuccesProb#최대 말 들을 확률
                    if dice > prob:#친밀도 + 거절확률보다 크면 대화 거부
                        c.friendliness -= minusFrByReject
                        c.save()
                        return JsonResponse({
                            'message' : {
                                'text' : rejProb.act
                            },
                            'keyboard' : {
                                'type' : 'buttons',
                                'buttons' : buttons[p.mode]
                            }
                        })

                    #대화 시도 성공
                    p.mode = 2#대화 모드로 넘어감
                    p.save()
                    mode2BtnAppend(c)#모드 2버튼들 추가
                    return JsonResponse({
                        'message' : {
                            'text' : '?'
                        },
                        'keyboard' : {
                            'type' : 'buttons',
                            'buttons' : buttons[p.mode]
                        }
                    })
                #elif content == debugBtnText : #상태확인
                    #r = getStatus(c)#상태확인 메세지 가져옴
                    #return JsonResponse({
                        #'message' : {
                            #'text' : r
                        #},
                        #'keyboard' : {
                            #'type' : 'buttons',
                            #'buttons' : buttons[p.mode]
                        #}
                    #})
                elif content == buttons[1][1]: #밥주기/용돈주기
                    result = upSatisfaction(c)
                    act = ''
                    checkStatus(c)
                    end = findEnding(c, p)
                    if end != None:
                    	return JsonResponse({
                    			'message' : {
                    				'text' : makeEndingMessage(end)
                    			},
                    			'keyboard' : {
                    				'type' : 'buttons',
                    				'buttons' : callChildBtn
                    			}
                    		})
                    if result == 0 : #모자람
                        act = '모자라요' #나중에 childTlak을 통해 수정해야함

                    elif result == 1 : #넘침
                        act = '넘쳐요' #나중에 childTalk을 통해 수정해야함
                    elif result == 3:#흡족
                        act = '잘 먹었습니다'

                    elif result == 4:#나이 증가
                        act = cName + "(이)는 떡국을 먹고 한 살 늘었다."
                        c.age += 1
                        c.month -= 12.0
                        c.ages = ages.objects.get(age = c.age)
                        c.save()
                        ageChange = True
                    selectedEvent = getEvent(c, p)#이벤트 발생 조사
                    if selectedEvent == None:#이벤트 발생 x
                        pass
                    else:#이벤트 발생함
                        act += '\n\n' + selectedEvent.act
 
                    return JsonResponse({
                        'message': {
                            'text': act
                        },
                        'keyboard': {
                            'type': 'buttons',
                            'buttons': buttons[p.mode]
                        }
                    })
                elif content == introduceBtnText: #자기소개하기
                	t = introduceChildSelf(c)
                	return JsonResponse({
                			'message' : {
                				'text' : t
                			},
                			'keyboard' : {
                				'type' : 'buttons',
                				'buttons' : buttons[p.mode]
                			}
                		})

               #다른 버튼
                return JsonResponse({
                    'message' : {
                        'text' : 'mode1 오류'
                    },
                    'keyboard' : {
                        'type' : 'buttons',
                        'buttons' : buttons[p.mode]
                    }
                })
            elif p.mode == 2:#mode2
                p.mode = 1
                p.save()

                try:
                    ct = getChildTalk(content, c)#아이의 말 가져옴
                    resultParsing(ct.result, c)#결과 적용
                except:
                    # mode2에서 없는 버튼
                    return JsonResponse({
                        'message': {
                            'text': 'mode2에서 오류'
                        },
                        'keyboard': {
                            'type': 'buttons',
                            'buttons': buttons[p.mode]
                        }
                    })
                checkStatus(c)
                end = findEnding(c, p)
                if end != None:
                	return JsonResponse({
                			'message' : {
                				'text' : makeEndingMessage(end)
                			},
                			'keyboard' : {
                				'type' : 'buttons',
                				'buttons' : callChildBtn
                			}
                		})
                
                text = ct.talk + '\n' + ct.result
                selectedEvent = getEvent(c, p)  # 이벤트 발생 조사
                if selectedEvent == None:  # 이벤트 발생 x
                    pass
                else:  # 이벤트 발생함
                    text += '\n\n' + selectedEvent.act
                
                if c.satisfaction <= lessSatisfaction:
                    text += '\n\n' + '꼬르륵...'#나중에 변경

                return JsonResponse({
                    'message' : {
                        'text' : text
                    },
                    'keyboard' : {
                        'type' : 'buttons',
                        'buttons' : buttons[p.mode]
                    }
                })

            elif p.mode == 3:#이벤트 모드
                p.mode = 1#모드 1로 돌아감
                p.save()
                try:
                    ec = eventChoice.objects.get(event = p.event_ing, choice = content)
                    resultParsing(ec.result, c)#이벤트 선택 결과로 스탯 변동
                    p.event_ing = None
                    p.save()
                    checkStatus(c)
                    end = findEnding(c, p)
                    if end != None:
                    	return JsonResponse({
                    			'message' : {
                    				'text' : makeEndingMessage(end)
                    			},
                    			'keyboard' : {
                    				'type' : 'buttons',
                    				'buttons' : callChildBtn
                    			}
                    		})
                    
                    return JsonResponse({
                        'message' : {
                            'text' : ec.act + '\n' + ec.result
                        },
                        'keyboard' : {
                            'type' : 'buttons',
                            'buttons' : buttons[p.mode]
                        }
                    })
                except:# 이벤트 없는데 이벤트 모드로 넘어옴
                    if p.event_ing != None:
                        p.mode = 3
                        p.save()
                    return JsonResponse({
                        'message': {
                            'text': '이벤트가 존재하지 않습니다.'
                        },
                        'keyboard': {
                            'type': 'buttons',
                            'buttons': buttons[p.mode]
                        }
                    })


#포만감의 증가
def upSatisfaction(c):
    c.satisfaction += plusSatisfaction
    c.month += mealCountForMonthUp
    c.save()
    if c.satisfaction > 100: #배터져 죽음
        return 2
    elif c.satisfaction <= lessSatisfaction: #너무 안줬음
        c.friendliness -= minusFrByGiven
        c.save()
        if c.month >= 13.0:
            return 4
        return 0
    elif c.satisfaction >= muchSatisfaction: #너무 줬음
        c.friendliness -= minusFrByGiven
        c.save()
        if c.month >= 13.0:
            return 4
        return 1
    else:#잘줬음
        c.friendliness += plusFrByGiven
        c.save()
        if c.month >= 13.0:
            return 4
        return  3

#아이의 죽음
def dieChild(c, p):
    c.delete()
    p.mode = 0
    p.event_ing = None
    p.save()

#mode1 버튼 결정
def mode1BtnAppend(c):
	buttons[1] = []
	chatBtn = c.name + '(이)야~'
	buttons[1].append(chatBtn)
	if c.age < eatSelfAge:
		buttons[1].append('밥 주기')
	else:
		buttons[1].append('용돈 주기')
	if len(buttons[1]) < mode1BtnSize and c.job.name != '아기':
		buttons[1].append(introduceBtnText)
	#buttons[1].append(debugBtnText)#디버그용
#mode2 버튼 결정
def mode2BtnAppend(c):
    buttons[2] = []  # 대화 선택지 버튼 초기화
    pt_talkList = []  # 대화 선택지 목록 초기화
    for pt in parentTalk.objects.filter(job=c.job):  # 가능한 대화목록 모두 가져옴
        pt_talkList.append(pt.talk)
    if c.age >= 20:
        for pt in parentTalk.objects.filter(job = job.objects.get(name = '어른')):
            pt_talkList.append(pt.talk)
    for i in range(0, mode2BtnSize):
        if len(pt_talkList) == 0:
            return 
        r = random.randrange(0, len(pt_talkList))
        buttons[2].append(pt_talkList[r])  # 대화 가능한 목록에서 임의로 하나 선택가능 버튼으로 추가
        del pt_talkList[r]  # 중복된 대화 없도록 선택된 대화는 제거

#mode3 버튼 결정ent_ing = None
def mode3BtnAppend(event, c):
	buttons[3] = []  # 이벤트 선택지 버튼 초기화
	if event.personality.id == -3:#대입시
		for ec in eventChoice.objects.filter(event = event):
			if ec.choice == '공대':
				if c.intelligence >= 50:
					buttons[3].append(ec.choice)
			elif ec.choice == '자연대':
				if c.intelligence >= 50:
					buttons[3].append(ec.choice)
			elif ec.choice == '예술대':
				if c.artAbility >= 50:
					buttons[3].append(ec.choice)
			elif ec.choice == '인문대':
				if c.morality >= 50:
					buttons[3].append(ec.choice)
			elif ec.choice == '의대':
				if c.morality >= 40 and c.intelligence >= 90:
					buttons[3].append(ec.choice)
			elif ec.choice == '법대':
				if c.morality >= 80 and c.intelligence >= 80:
					buttons[3].append(ec.choice)
		if buttons[3] == []:
			buttons[3].append('보낼 수 있는 학교가 없다')
		else:
			buttons[3].append('보내지 않는다')
		return
	for ec in eventChoice.objects.filter(event = event):
		buttons[3].append(ec.choice)  # 이벤트 선택지 추가
#상태 가져오기
def getStatus(c):
    return '이름 : ' + c.name + '\n나이 : ' + str(c.age) + '\n성장기 : ' + c.ages.name + '\n성격 : ' + c.personality.name + '\n직업 : ' + c.job.name + '\n친밀도 : ' + str(c.friendliness) + '\n포만감 : ' + str(c.satisfaction) + '\n지능 : ' + str(c.intelligence) + '\n도덕심 : ' + str(c.morality) + '\n예술성 : ' + str(c.artAbility) + '\n달 : ' + str(c.month) + '월'
def getChildTalk(content, c):
    ctList = []
    for ct in childTalk.objects.filter(parent_talk_id = -1):
        ctList.append(ct)
    try:
        pt = parentTalk.objects.get(talk=content, job=c.job)
        for ct in childTalk.objects.filter(parent_talk=pt):  # 자기 성격 or 공통 반응 추출
            if ct.personality == c.personality or ct.personality == personality.objects.get(id=-1):
                ctList.append(ct)
    except:
        if c.age >= 20:
            pt = parentTalk.objects.get(talk = content, job = job.objects.get(name = '어른'))
            for ct in childTalk.objects.filter(parent_talk = pt):
                if ct.personality == c.personality or ct.personality == personality.objects.get(id = -1):
                    ctList.append(ct)
    return ctList[random.randrange(0, len(ctList))]  # 추출된 childTalk 중 랜덤으로 하나 뽑아냄

#결과의 적용
def resultParsing(result, c):
    #result를 a에 '친밀도', '+', '5' 형식으로 쪼개넣음
    a = []
    s = ''
    for ch in result:
        if ch == ' ' or ch == ',':
            if s != '':
                a.append(s)
                s = ''
        elif ch == '+' or ch == '-' or ch == '=':
            if s != '':
                a.append(s)
                s = ''
            a.append(ch)
        else:
            s += ch
    a.append(s)

    #a에 따라 결과 적용
    for i in range(0, len(a)):
        if i % 3 == 1:
            if a[i] == '+':
                if a[i - 1] == '친밀도':
                    c.friendliness += int(a[i + 1])
                    c.save()
                elif a[i - 1] == '포만감':
                    c.satisfaction += int(a[i + 1])
                    c.save()
                elif a[i - 1] == '지능':
                    c.intelligence += int(a[i + 1])
                    c.save()
                elif a[i - 1] == '도덕심':
                    c.morality += int(a[i + 1])
                    c.save()
                elif a[i - 1] == '예술성':
                    c.artAbility += int(a[i + 1])
                    c.save()
            elif a[i] == '-':
                if a[i - 1] == '친밀도':
                    c.friendliness -= int(a[i + 1])
                    c.save()
                elif a[i - 1] == '포만감':
                    c.satisfaction -= int(a[i + 1])
                    c.save()
                elif a[i - 1] == '지능':
                    c.intelligence -= int(a[i + 1])
                    c.save()
                elif a[i - 1] == '도덕심':
                    c.morality -= int(a[i + 1])
                    c.save()
                elif a[i - 1] == '예술성':
                	c.artAbility -= int(a[i + 1])
                	c.save()
            elif a[i] == '=':
                if a[i - 1] == '성격':
                    c.personality = personality.objects.get(id = int(a[i + 1]))
                    c.save()
                elif a[i - 1] == '직업':
                    c.job = job.objects.get(name = a[i + 1])
                    c.save()

#이벤트 결정
def getEvent(c, p):
    try:#필수 진행 이벤트 탐색
        if ageChange and c.age == 20:#대학 진학
            ev = event.objects.get(personality = personality.objects.get(id = -3))
        elif ageChange and (c.job.name == '아기' or c.job.name == '어린이' or c.job.name == '유치원생'):
            ev = event.objects.get(personality = personality.objects.get(id = -2), job = job.objects.get(name = '아기'),minAge = c.age)#초등학교 입학까지의 필수 전직 이벤트
        elif not ageChange and (c.job.name == '아기' or c.job.name == '어린이' or c.job.name == '유치원생'):
            ev = event.objects.get(personality = personality.objects.get(id = -2), job = job.objects.get(name = '초등학생'), minAge  = c.age)#초등학교 입학까지 반복 물음 못하게
        else:
            ev = event.objects.get(personality = personality.objects.get(id = -2), job = c.job, minAge = c.age)
        p.mode = 3 #이벤트 모드로 변경
        p.event_ing = ev
        p.save()
        mode3BtnAppend(ev, c)
        return ev#필수 진행 이벤트 넣음
    except:#확률 적으로 이벤트 탐색
        r = random.randrange(0, 100)
        if r >= eventProbability:#이벤트 발생하지 않음
            return None
        else:
            eList = []
            for ev in event.objects.filter(job = c.job, minAge__lte = c.age, maxAge__gte = c.age):
                if ev.personality == c.personality or ev.personality == personality.objects.get(id = -1):
                    eList.append(ev)
            if eList == []:  # event가 없음
                return None
            else:#이벤트 존재
                ev = eList[random.randrange(0, len(eList))]  # 이벤트 임의로 선택
                p.mode = 3  # 이벤트 모드로 변경
                p.event_ing = ev
                p.save()
                mode3BtnAppend(ev, c)  # 이벤트 버튼 초기화
                return ev

def findEnding(c, p) :
	endList = []
	dice = random.randrange(0, 1000)
	if dice == 1:#천재지변 발생
		for end in ending.objects.filter(
			suddenDeath = 1,
			minAge__lte = c.age, maxAge__gte = c.age,
			minSatis__lte = c.satisfaction, maxSatis__gte = c.satisfaction,
			minInt__lte = c.intelligence, maxInt__gte = c.intelligence,
			minFr__lte = c.friendliness, maxFr__gte = c.friendliness,
			minMor__lte = c.morality, maxMor__gte = c.morality):
			endList.append(end)
		if endList != []:
			end = endList[random.randrange(0, len(endList))]
			dieChild(c, p)
			return end
	#천재지변이 아닌경우
	for i in range (maxEndingPriority, -1, -1): #우선순위가 높은 순으로 엔딩 결정
		endList = []#해당 우선순위에 해당하는 이벤트가 없을 시 초기화
		for end in ending.objects.filter(
			suddenDeath = 0,
			minAge__lte = c.age, maxAge__gte = c.age,
			minSatis__lte = c.satisfaction, maxSatis__gte = c.satisfaction,
			minInt__lte = c.intelligence, maxInt__gte = c.intelligence,
			minFr__lte = c.friendliness, maxFr__gte = c.friendliness,
			minMor__lte = c.morality, maxMor__gte = c.morality,
			minArt__lte = c.artAbility, maxArt__gte = c.artAbility,
			priority = i):
			if end.job == c.job or end.job == job.objects.get(name = '공통'): #직업트리 엔딩과 공통엔딩 높은 우선순위로 추출
				endList.append(end)
		if endList != []:
			dieChild(c, p)
			end = endList[random.randrange(0, len(endList))]
			return end
		else:
			pass#이벤트 없으면 다음 우선순위 이벤트 탐색
	return None#아무런 이벤트도 존재하지 않음

def makeEndingMessage(end):
	m = '엔딩' + str(end.id) + ' : ' + end.title + '\n\n'
	m += '"' + end.result + '"\n\n'
	m += '평점 : '
	for i in range(0, end.score):
		m += '★'
	return m 
			
def checkStatus(c):
	if c.friendliness > 100:
		c.friendliness = 100
	elif c.friendliness < 0:
		c.friendliness = 0
	if c.satisfaction > 100:
		c.satisfaction = 100
	elif c.satisfaction < 0:
		c.satisfaction = 0
	if c.intelligence > 100:
		c.intelligence = 100
	elif c.intelligence < 0:
		c.intelligence = 0
	if c.morality > 100:
		c.morality = 100
	elif c.morality < 0:
		c.morality = 0
	if c.artAbility > 100:
		c.artAbility = 100
	elif c.artAbility < 0:
		c.artAbility = 0
	c.save()

def introduceChildSelf(c):
	text = '안녕! 내 이름은 ' + c.name + ', ' + c.job.name + '(이)야!\n'
	text += '나이는 ' + str(c.age) + '살! 내 성격은 ' + c.personality.name + '이지!\n'
	text +=  '나는 부모님'
	if c.friendliness >= 80:
		text += '을 정말 좋아해!'
	elif 60 <= c.friendliness < 90:
		text += '을 잘 따르는 편이야!'
	elif 40 <= c.friendliness < 60:
		text += '을 그럭저럭 잘 따르고 있어.'
	elif 20 <= c.friendliness < 40:
		text += ' 말을 별로 듣고싶지 않아.'
	else:
		text += '이 싫어.'
	text += '\n난 지금 '
	if c.age >= eatSelfAge:
		if c.satisfaction >= muchSatisfaction:
			text += '돈이 너무 많아서 어쩔 줄 모르겠어!'
		elif 60 <= c.satisfaction < muchSatisfaction:
			text += '정말로 필요한 건 스스로 살 수 있어서 좋아!'
		elif 40 <= c.satisfaction < 60:
			text += '그럭저럭 용돈을 받고 있어!'
		elif lessSatisfaction <= c.satisfaction < 40:
			text += '용돈이 조금 부족한 것 같아.'
		else:
			text += '용돈이 없어.'
	else:
		if c.satisfaction >= muchSatisfaction:
			text += '짜증날 정도로 배가 불러!'
		elif 60 <= c.satisfaction < muchSatisfaction:
			text += '배불러서 기분아 좋아!'
		elif 40 <= c.satisfaction < 60:
			text += '그럭저럭 배가 불러!'
		elif lessSatisfaction <= c.satisfaction < 40:
			text += '조금 배가 고파'
		else:
			text += '배고파서 죽을 것 같아...'
	text += '\n난 '
	if c.intelligence >= 80:
		text += '정말 똑똑한 편이야!'
	elif 60 <= c.intelligence < 80:
		text += '남들 만큼은 똑똑한 편이야!'
	elif 40 <= c.intelligence < 60:
		text += '아직 모르는 게 많아!'
	elif 20 <= c.intelligence < 40:
		text += '아는 게 별로 없어.'
	else:
		text += '아무것도 아는 게 없어.'
	text += '\n그리고 '
	if c.morality >= 80:
		text += '내가 곧 정의야!'
	elif 60 <= c.morality < 80:
		text += '난 불의를 잘 참지 못해!'
	elif 40 <= c.morality < 60:
		text += '나쁜 짓은 조금 망설여져!'
	elif 20 <= c.morality < 40:
		text += '나쁜 짓은 해도 걸리지만 않으면 된다고 생각해.'
	else:
		text += '착한척 하는 것들을 이해할 수가 없어.'
	text += '\n난 '
	if c.artAbility >= 80:
		text += '미적 감각이 타고난 것 같아!'
	elif 60 <= c.artAbility < 80:
		text += '미적 감각이 꽤 있는 것 같아!'
	elif 40 <= c.artAbility < 60:
		text += '예술은 그럭저럭 괜찮은 것이라고 생각해!'
	elif 20 <= c.artAbility < 40:
		text += '예술성 같은 건 존재하지 않는다고 생각해.'
	else:
		text += '예술따윈 부숴버리면 그만이라고 생각해.'
	return text