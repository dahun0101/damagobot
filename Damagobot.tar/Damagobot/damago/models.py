# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
import datetime

class personality(models.Model):
    name = models.CharField(max_length = 20)

class job(models.Model):
    name = models.CharField(max_length = 20, primary_key = True)
    intelligence = models.IntegerField(default = 0)
    morality = models.IntegerField(default = 0)
    artAbility = models.IntegerField(default = 0)
    personality = models.ForeignKey(personality, on_delete = models.CASCADE)
    age = models.IntegerField(default = 0)

class ages(models.Model):
    name = models.CharField(max_length = 20)
    age = models.IntegerField(default = 0)

class parentTalk(models.Model):
    talk = models.CharField(max_length = 30)
    job = models.ForeignKey(job, on_delete = models.CASCADE, null = True)

class childTalk(models.Model):
    talk = models.CharField(max_length = 50)
    result = models.CharField(max_length = 30)
    parent_talk = models.ForeignKey(parentTalk, on_delete = models.CASCADE)
    personality = models.ForeignKey(personality, on_delete = models.CASCADE)


class event(models.Model):
    name = models.CharField(max_length = 30)
    job = models.ForeignKey(job, on_delete = models.CASCADE)
    minAge = models.IntegerField(default = 0)
    maxAge = models.IntegerField(default = 0)
    personality = models.ForeignKey(personality, on_delete = models.CASCADE)
    act = models.CharField(max_length = 50, null = True)
class eventChoice(models.Model):
    event = models.ForeignKey(event, on_delete = models.CASCADE)
    choice = models.CharField(max_length = 20)
    result = models.CharField(max_length = 30, null = True)
    act = models.CharField(max_length = 50, null = True)

class talkRejection(models.Model):
    personality = models.ForeignKey(personality, on_delete = models.CASCADE, unique = True)
    probability = models.IntegerField(default = 20)
    act = models.CharField(max_length = 50)

class parent(models.Model):
    ID = models.CharField(max_length = 50, primary_key = True)
    mode = models.IntegerField(default = 0)
    event_ing = models.ForeignKey(event, null = True, on_delete = models.CASCADE)

class child(models.Model):
    name = models.CharField(max_length = 30)
    age = models.IntegerField(default = 1)
    friendliness = models.IntegerField(default = 50)
    satisfaction = models.IntegerField(default = 50)
    intelligence = models.IntegerField(default = 0)
    morality = models.IntegerField(default = 0)
    artAbility = models.IntegerField(default = 0)
    parent = models.OneToOneField(parent, on_delete = models.CASCADE)
    last_datetime = models.DateTimeField(default = datetime.datetime.now())
    personality = models.ForeignKey(personality, on_delete = models.CASCADE)
    job = models.ForeignKey(job, on_delete = models.CASCADE)
    ages = models.ForeignKey(ages, on_delete = models.CASCADE)
    month = models.FloatField(default = 1.0)

class ending(models.Model):
    title = models.CharField(max_length = 10)
    result = models.CharField(max_length = 50)
    job = models.ForeignKey(job, on_delete = models.CASCADE, null = True)
    minAge = models.IntegerField(default = 0)
    maxAge = models.IntegerField(default = 100)
    minSatis = models.IntegerField(default = 0)
    maxSatis = models.IntegerField(default = 100)
    minInt = models.IntegerField(default = 0)
    maxInt = models.IntegerField(default = 100)
    minFr = models.IntegerField(default = 0)
    maxFr = models.IntegerField(default = 100)
    minMor = models.IntegerField(default = 0)
    maxMor = models.IntegerField(default = 100)
    minArt = models.IntegerField(default = 0)
    maxArt = models.IntegerField(default = 100)
    suddenDeath = models.IntegerField(default = 0)
    score = models.IntegerField(default = 1)
    priority = models.IntegerField(default = 0)

